CS 411 
Project 1
Search in Pacman
Latika Bhurani (NetID - lbhura2), Malavika Srinivas (NetID - msrini8)
 
Pac-Man is an arcade game developed by Namco and was created by Japanese video game designer Toru Iwatani. The goal of the game is to accumulate points by eating all the dots known as Pac-Dots in the maze by exploring as less nodes as possible and avoid getting killed by the four multi-colored ghosts: Blinky, Pinky, Inky and Clyde.
This project implements:
 
Q1: Depth First Search
Q2: Breadth First Search
Q3: Uniform Cost Search
Q4: A* Search
Q5: Corners Problem: Representation
Q6: Corners Problem: Heuristic
Q7: Eating All The Dots: Heuristic
Q8: Suboptimal Search
 
Question 1: Finding a Fixed Food Dot using Depth First Search
This graph search version of DFS that is implemented in the depthFirstSearch function in search.py and avoids expanding any already visited states. This path is found in cost 10 exploring 15 nodes for the tinyMaze, 130 cost and 380 nodes explored for mediumMaze and 210 cost and 390 nodes explored for bigMaze.
The answers for the questions are as follows:
Is the exploration order what you would have expected?             
Yes

Does Pacman actually go to all the explored squares on his way to the goal?
No, it does not explore all the nodes because we are implementing the graph search version of DFS.

Is this a least cost solution? If not, think about what depth-first search is doing wrong.
This is not the least cost solution as it explores the successor nodes and finds the leftmost solution.
 
Question 2: Breadth First Search
This implements the breadth-first search (BFS) algorithm in the breadthFirstSearch function in search.py and is again a graph search algorithm that avoids expanding any already visited states. This implements BFS with cost 8 by exploring 10 nodes in the tinyMaze, cost 68 by exploring 269 nodes in the mediumMaze and cost 210 by exploring 620 nodes in the bigMaze. This code also works equally well for the eight-puzzle search problem without any changes.
 
Question 3: Varying the Cost Function
This implements the uniform-cost graph search algorithm in the uniformCostSearch function in search.py. UCS finds the path with cost 68 by exploring 269 nodes in the mediumMaze, cost 1 by exploring 186 in the mediumDottedMaze with StayEastSearchAgent
and cost 68719479864 by exploring 108 nodes with StayWestSearchAgent. The path costs difference is very high due to the exponential cost function implemented in searchAgents.py.
 
Question 4: A* search
This implements A* graph search in the empty function aStarSearch in search.py. A* takes a heuristic function as an argument. Heuristics take two arguments: a state in the search problem (the main argument), and the problem itself (for reference information). A* search finds the path in cost 219 by exploring 549 nodes in the bigMaze. So far A* graph search is the best optimal solution.
When we implement the same thing on openMaze, we get different results for various search algorithms:
 Search Algorithm	Cost	No of nodes expanded
	UCS		54	682
	BFS		54	682
	DFS		298	576
	A*		54	535
	 
Question 5: Finding All the Corners
This implements the CornersProblem search problem in searchAgents.py. In corner mazes, there are four dots, one in each corner. This new search algorithm finds the shortest path through the maze that touches all four corners (whether the maze actually has food there or not). The path is found with cost 28 expanding 252 nodes in the tinyCorners maze, cost 106 expanding 1966 nodes in the mediumCorners maze. For some mazes like tinyCorners, the shortest path does not always go to the closest food first.
 
Question 6: Corners Problem: Heuristic
This implements a non-trivial, consistent heuristic for the CornersProblem in cornersHeuristic.This heuristic is a non-trivial non-negative consistent heuristic and returns 0 at every goal state. This path found is of cost 106 expanding 1226 nodes.

Question 7: Eating All The Dots
The UCS or A* function implements the search and finds the optimal path but with null heuristics. We improve this search by adding heuristic function. The foodHeuristic in searchAgents.py is filled with a consistent heuristic for the FoodSearchProblem. UCS agent finds the optimal solution in about 13 seconds, exploring over 16,000 nodes. This heuristic returns 0 at every goal state and never returns a negative value. But with optimization, the path is found with cost 60 by expanding 5349 nodes.

Question 8: Suboptimal Search
This implements the function findPathToClosestDot in searchAgents.py by using the BFS search function. The agent solves this maze suboptimally, by greedily eating the closest dot in under a second with a path cost of 350. The ClosestDotSearchAgent won't always find the shortest possible path through the maze as it always eats the closest dot greedily.